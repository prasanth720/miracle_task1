import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsersService {



  constructor(private http:HttpClient) { }

  getusers()
  {
      let users =JSON.parse(localStorage.getItem("user1") || '{}')
      
    return users
  }
  create_user(data:any)
  {
    let users =JSON.parse(localStorage.getItem('user1') || '[]')
    console.log(users)
    users.push(data)
   
    localStorage.setItem('user1',JSON.stringify(data))

  }

  deleteuser(data:number){
    let users =JSON.parse(localStorage.getItem('user1')|| '[]')
    for(let i=0 ;i<users.length;i++){
      if(users[i].EmpID==data)
      {
        users.splice(i,1)
      }
      localStorage.setItem('user1', JSON.stringify(users));
      
    }
   
  }
  updateUser(olduser,newuser){
    let users =JSON.parse(localStorage.getItem('user1') || '[]' )

    for( let i=0 ;i<users.length;i++)
    {
      if(users[i]==olduser)
      {
        users[i]=newuser
      }
    }
    localStorage.setItem('user1',users)
  }
}


