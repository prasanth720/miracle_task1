import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-html-screen',
  templateUrl: './html-screen.component.html',
  styleUrls: ['./html-screen.component.css']
})
export class HtmlScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
