import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  reactiveForm: FormGroup;
  lang = [
    { name: "HTML" },
    { name: "ReactJS" },
    { name: "Angular" },
    { name: "Bootstrap" },
    { name: "PrimeNG" },
  ];

  country = [
    { name: 'Afghanistan'},
    { name: 'Åland Islands' },
    { name: 'Albania' },
    { name: 'Algeria' },
    { name: 'Bahamas' },
    { name: 'Bahrain' },
    { name: 'Bangladesh' },
    { name: 'Barbados' },
    { name: 'Cameroon' },
    { name: 'Canada'},
    { name: 'Cape Verde' },
    { name: 'Cayman Islands' },
    { name: 'Central African Republic' },
    { name: 'Chad' },
    { name: 'Chile'},
    { name: 'China' },
    { name: 'Christmas Island' },
    { name: 'Cocos (Keeling) Islands' },
    { name: 'Colombia' },
    { name: 'Comoros', code: 'KM' },
    { name: 'Iceland', code: 'IS' },
    { name: 'India', code: 'IN' },
    { name: 'Indonesia', code: 'ID' },
    { name: 'Iran, Islamic Republic Of', code: 'IR' },
    { name: 'Iraq', code: 'IQ' },
    { name: 'Ireland', code: 'IE' },
    { name: 'Isle of Man', code: 'IM' },
    { name: 'Israel', code: 'IL' },
    { name: 'Italy', code: 'IT' },
    { name: 'Jamaica', code: 'JM' },
    { name: 'Japan', code: 'JP' },
    { name: 'United Arab Emirates', code: 'AE' },
    { name: 'United Kingdom', code: 'GB' },
    { name: 'United States', code: 'US' },
    { name: 'United States Minor Outlying Islands', code: 'UM' },
    { name: 'Uruguay', code: 'UY' },
    { name: 'Uzbekistan', code: 'UZ' },
    { name: 'Vanuatu', code: 'VU' },
    { name: 'Venezuela', code: 'VE' },
    { name: 'Viet Nam', code: 'VN' },
    { name: 'Virgin Islands, British', code: 'VG' },
    { name: 'Virgin Islands, U.S.', code: 'VI' },
    { name: 'Wallis and Futuna', code: 'WF' },
    { name: 'Western Sahara', code: 'EH' },
    { name: 'Yemen', code: 'YE' },
    { name: 'Zambia', code: 'ZM' },
    { name: 'Zimbabwe', code: 'ZW' }
  ];

  district = [
    { name: "srikakulam" },
    { name: "vizianagaram" },
    { name: "vishkapatanam" },
    { name: "East godavari" },
    { name: "West godavari" },
    { name: "rajamehendravaram" },
    { name: "vijayawada" },
    { name: "guntur" },
    { name: "prakasam" },
    { name: "tirupathi" },
    { name: "kadapa" },
    { name: "kurnool" },
    { name: "ananthapuram" }

  ];
  states = [
    { name: "Andaman and Nicobar Islands" },
    { name: "Andhra Pradesh" },
    { name: "Arunachal Pradesh" },
    { name: "Assam" },
    { name: "Bihar" },
    { name: "Chandigarh" },
    { name: "Chhattisgarh" },
    { name: "Dadra and Nagar Haveli" },
    { name: "Daman and Diu" },
    { name: "Delhi" },
    { name: "Goa" },
    { name: "Gujarat" },
    { name: "Haryana" },
    { name: "Himachal Pradesh" },
    { name: "Jammu and Kashmir" },
    { name: "Jharkhand" },
    { name: "Karnataka" },
    { name: "Kerala" },
    { name: "Ladakh" },
    { name: "Lakshadweep" },
    { name: "Madhya Pradesh" },
    { name: "Maharashtra" },
    { name: "Manipur" },
    { name: "Meghalaya" },
    { name: "Mizoram" },
    { name: "Nagaland" },
    { name: "Orissa" },
    { name: "Pondicherry" },
    { name: "Punjab" },
    { name: "Rajasthan" },
    { name: "Sikkim" },
    { name: "Tamil Nadu" },
    { name: "Telangana" },
    { name: "Tripura" },
    { name: "Uttaranchal" },
    { name: "Uttar Pradesh" },
    { name: "West Bengal" }]
  swift = [
      { timings: "2PM - 11PM" },
      { timings: "3PM - 12AM" },
      { timings: "4PM - 1AM" },
      { timings: "6PM - 3AM" },
  
    ];
depart = [
      { name: "B2B" },
      { name: "MEAN STACK" },
      { name: "DATABASE" },
      { name: "SAP" },
      { name: "INTEGRATION" },
    ];

    
  facebook = [
    { name: "Active" },
    { name: "Inactive" }
  ]
  linkedin = [{ name: "Active" },
  { name: "Inactive" }]
  twitter = [{ name: "Active" },
  { name: "Inactive" }]

 
 
  empid: any;
  user1: any;
  msgs: any;
  msgs1:any;
  users: any;

  constructor(private formBuilder: FormBuilder,private service:UsersService, public roter: Router, public aroute: ActivatedRoute) { }

  ngOnInit(): void {
    this.reactiveForm = this.formBuilder.group({
      FirstName: ['', [Validators.required, Validators.pattern('^[\\sa-zA-z]*$')]],
      MiddleName: ['', [Validators.pattern('^[\\sa-zA-z]*$')]],
      LastName: ['', [Validators.required, Validators.pattern('^[\\sa-zA-z]*$')]],
      EmpID: ['', [Validators.required, Validators.pattern('^[\\sa-zA-z]*$')]],
      Status: ['', [Validators.required, Validators.pattern('^[\\sa-zA-z]*$')]],
      Originzation: ['', [Validators.required, Validators.pattern('^[\\sa-zA-z]*$')]],
      Department: ['', [Validators.required, Validators.pattern('^[\\sa-zA-z]*$')]],
      Swift_Timings: ['', [Validators.required, Validators.pattern('^[\\sa-zA-z]*$')]],
      doj: ['', Validators.required],
      gender: ['', [Validators.required, Validators.pattern('^[\\sa-zA-z]*$')]],
      Work_Phone: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      Personal_Phone: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      Cooparate_mail: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_.]+@[a-zA-Z]+.[a-z.]{2,7}')]],
      Personal_mail: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_.]+@[a-zA-Z]+.[a-z.]{2,7}')]],
      Skills: ['', [Validators.required, Validators.pattern('^[\\sa-zA-z]*$')]],
      Address1: ['', [Validators.required]],
      Address2: ['', [Validators.required]],
      Country: ['', [Validators.required]],
      State: ['', [Validators.required]],
      City: ['', [Validators.required]],
      zip: ['', [Validators.required]],
      Facebook:['',[Validators.required]],
      LinkedIn:['',[Validators.required]],
      Twitter:['',[Validators.required]]

    })
    this.empid = this.aroute.snapshot.params.emp;
    console.log(this.empid)
    this.patchData()
  }
  patchData() {
    this.users = JSON.parse(localStorage.getItem('user1') || '{}');
    console.log("getdata", this.users)
    this.users.forEach(element => {
      // console.log(element)
      if (element.EmpID == this.empid) {
        this.user1 = element
        console.log("user data",this.user1)
      }
    });
    this.reactiveForm.controls.Address1.patchValue(this.user1.Address1),
    this.reactiveForm.controls.Address2.patchValue(this.user1.Address2),
    this.reactiveForm.controls.City.patchValue(this.district.filter(x =>x.name ===this.user1.City )[0]),
    this.reactiveForm.controls.Cooparate_mail.patchValue(this.user1.Cooparate_mail),
    // this.reactiveForm.controls.Country.patchValue(this.user1.Country this.country.filter()),
    this.reactiveForm.controls.Department.patchValue(this.depart.filter(x =>x.name ===this.user1.Department)[0]),  
    this.reactiveForm.controls.EmpID.patchValue(this.user1.EmpID),
    this.reactiveForm.controls.FirstName.patchValue(this.user1.FirstName),
    this.reactiveForm.controls.LastName.patchValue(this.user1.LastName),
    this.reactiveForm.controls.MiddleName.patchValue(this.user1.MiddleName),
    this.reactiveForm.controls.Originzation.patchValue(this.user1.Originzation),
    this.reactiveForm.controls.Personal_Phone.patchValue(this.user1.Personal_Phone),
    this.reactiveForm.controls.Personal_mail.patchValue(this.user1.Personal_mail),
    this.reactiveForm.controls.Skills.patchValue(this.lang.filter(x=>x.name === this.user1.Skills)[0]),
    this.reactiveForm.controls.State.patchValue(this.user1.State),
    this.reactiveForm.controls.Status.patchValue(this.user1.Status),
    console.log(this.user1.Country)
      console.log(this.country)
      this.reactiveForm.controls.Country.patchValue(this.country.filter(x =>x.name ===this.user1.Country)[0])
      // this.reactiveForm.controls.Swift_Timings.patchValue(this.user1.Swift_Timings),
      this.reactiveForm.controls.Work_Phone.patchValue(this.user1.Work_Phone),
      // this.reactiveForm.controls.doj.patchValue(this.user1.doj),
      this.reactiveForm.controls.gender.patchValue(this.user1.gender),
      this.reactiveForm.controls.zip.patchValue(this.user1.zip)
      this.reactiveForm.controls.Facebook.patchValue(this.user1.Facebook),
      this.reactiveForm.controls.LinkedIn.patchValue(this.user1.LinkedIn),
      this.reactiveForm.controls.Twitter.patchValue(this.user1.twitter)
      
    // console.log("data",this.data,this.reactiveForm.value)
  }

  onUpdate()
  {
      console.log("user",this.user1)
    const data = {
      Address1:this.reactiveForm.value.Address1 ,
      Address2:this.reactiveForm.value.Address2,
      City:this.reactiveForm.value.City,
      Cooparate_mail:this.reactiveForm.value.Cooparate_mail,
      Country:this.reactiveForm.value.Country ,
      Department:this.reactiveForm.value.Department ,
      EmpID:this.reactiveForm.value.EmpID ,
      FirstName:this.reactiveForm.value.FirstName ,
      LastName: this.reactiveForm.value.LastName,
      MiddleName:this.reactiveForm.value.MiddleName ,
      Originzation:this.reactiveForm.value.Originzation ,
      Personal_Phone:this.reactiveForm.value.Personal_Phone ,
      Personal_mail:this.reactiveForm.value.Personal_mail ,
      Skills:this.reactiveForm.value.Skills ,
      State:this.reactiveForm.value.State,
      Status: this.reactiveForm.value.Status,
      Swift_Timings:this.reactiveForm.value.Swift_Timings,
      Work_Phone:this.reactiveForm.value.Work_Phone ,
      doj: this.reactiveForm.value.doj,
      gender:this.reactiveForm.value.gender ,
      zip:this.reactiveForm.value.zip,
      Facebook: this.reactiveForm.value.Facebook,
      LinkedIn: this.reactiveForm.value.LinkedIn,
      Twitter: this.reactiveForm.value.Twitter
    }
    if(this.reactiveForm.invalid)
    {
    this.service.updateUser(this.empid,data)
    this.msgs = [{ severity: 'success', summary: 'success', detail: 'User  Added  Successfully' }]
    this.roter.navigate(['/purchase'])
    }
    else{
      // this.reactiveForm.markAllAsTouched();
      this.msgs1 = [{ severity: 'warn', summary: 'warn', detail: 'User not Added ' }]
    }  
  }
}