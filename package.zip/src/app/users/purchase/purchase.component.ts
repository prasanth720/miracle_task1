import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { Observable } from 'rxjs';
import { UsersService } from '../users.service';
@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.css']
})
export class PurchaseComponent implements OnInit {


  items: any;
  data: any;
  gSearch: ''
  basicData: any;
  mydate = Date.now();
  basicOptions: any;
  data1: any
  users: any;
  user3: boolean;
  constructor(private service: UsersService, private route: Router) { }

  ngOnInit(): void {
    this.data = this.service.getusers()
    console.log(this.data)
  }

  add() {
    this.route.navigate(['/addPurchase'])
    // const gridData = JSON.parse(sessionStorage.getItem('grid') || '{}')
    // console.log(gridData)
  }

  edit(emp: number) {
    console.log(emp)
    this.route.navigate(["/edit", emp])
  }

  deleteUser(emp: number) {
    console.log(emp)
    let users =JSON.parse(localStorage.getItem('user1')|| '[]')

    
    for(let i=0 ;i<users.length;i++){
      if(users[i].EmpID==emp)
      {
        this.user3=confirm("are you delete user?")
        if(this.user3==true){
        users.splice(i,1)
        }
      }
      this.route.navigate(['/Purchase'])
      localStorage.setItem('user1', JSON.stringify(users));
      
    }
    // this.service.deleteuser(emp)

    

  }

}
